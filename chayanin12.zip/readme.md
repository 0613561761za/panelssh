#SSHPANEL
###An easy panel to manage SSH User's.

This script is used to SSH seller to easily manage SSH user or create reseller.

## System Requirements

* PHP 5.2 >=
* PDO PHP Extension
* OpenSSL PHP Extension
* Mbstring PHP Exstension
* Tokenizer PHP Exstension
* XML PHP Exstension
* exec()

## License

SSHPANEL Is under [MIT License](https://opensource.org/licenses/MIT)

## Developers

**Rizal Fakhri Maha Putra**

* Github @rizalio
* Facebook @rizaldotio
* Blog https://www.rizal.io

## Special Thanks to

**People who help me on Developing  proccess**

* [@neubert](http://stackoverflow.com/users/569976/neubert)
* [@tanerkuc](http://stackoverflow.com/users/227562/tanerkuc)
* [@maiorano84](http://stackoverflow.com/users/1347308/maiorano84)
* [@can-celik](http://stackoverflow.com/users/2951316/can-celik)
* [@ollieread](http://stackoverflow.com/users/3104359/ollieread)
* [@ridho-virman](https://web.facebook.com/scriptkiddies777)

## Donate

**This application is FREE**
But if you will you can donate to me with place my ads code on this app :)

## How To Install

**Please Read the Wiki**
